Shape Hover Effect with SVG
=========

*In this tutorial we'll recreate the hover effect as seen on The Christmas Experiments website. We'll be using SVG for the shape and Snap.svg for animating it on hover.*

[Article on Codrops](http://tympanus.net/codrops/?p=18145)

[Demo](http://tympanus.net/Tutorials/ShapeHoverEffectSVG/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Illustrations by [Isaac Montemayor](http://cargocollective.com/isaac317)

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)