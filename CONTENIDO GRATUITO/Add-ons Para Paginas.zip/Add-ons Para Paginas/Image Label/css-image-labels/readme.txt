Pixels Daily
=======================
Item: CSS Image Labels
Type: HTML/CSS/
Author: Josh Johnson



Notes
=======================
This download includes a simple animated label that appears over an image on hover. To ensure versatility, ten different options have been included, each of which slides in from a different direction or rests in a different location.

To apply the labels to an image, all you need to do is follow the simple HTML structure of the example file and apply the class for the label that you'd like to use.

You can see a full tutorial on this image label library on <a href="http://designshack.net/articles/css/imagelabellibrary/">Design Shack</a> or see a live demo <a href="http://designshack.net/tutorialexamples/imagelabellibrary/index.html">here</a>.


Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit Design Curate for the original creation:

http://creativecommons.org/licenses/by/3.0/