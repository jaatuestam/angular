LICENSES
========

Entypo by Daniel Bruce - CC BY-SA 3.0 - http://creativecommons.org/licenses/by-sa/3.0/
--------------------------------------------------------------------------------------

Autumn Rain by 55Laney69 - CC BY 2.0 - http://www.flickr.com/photos/hansel5569/6453298167
-----------------------------------------------------------------------------------------

