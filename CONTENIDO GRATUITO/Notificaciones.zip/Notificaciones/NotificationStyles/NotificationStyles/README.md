Notification Styles Inspiration
=========

Various simple ideas and effects for unobtrusive notifications on a website.

[Article on Codrops](http://tympanus.net/codrops/?p=19415)

[Demo](http://tympanus.net/Development/NotificationStyles)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)

[© Codrops 2014](http://www.codrops.com)