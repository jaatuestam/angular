
Progress Button Styles
=========

A set of flat and 3D progress button styles where the button itself serves as a progress indicator. 3D styles are used for showing the progress indication on one side of the button while rotating the button in perspective.

[Article on Codrops](http://tympanus.net/codrops/?p=17809)

[Demo](http://tympanus.net/Development/ProgressButtonStyles/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)